""" Discretization of coupling terms for mixed-dimensional problems.
"""
