# Numerical schemes
* finite volumes schemes for flow, elasticity, and transport [fv](fv)
* virtual element methods for flow [vem](vem)
* solver and mixed-dimensional interfaces [mixed_dim](mixed_dim)
