""" Implementation of methods related to the virtual element method.
"""
