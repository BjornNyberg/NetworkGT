""" This package contains various modules related to geometry modifications.

As a historical comment, many of the functions were previously located
in pp.utils.comp_geom.py
"""
