from porepy.ad.forward_mode import Ad_array, initAdArrays

from porepy.ad.functions import exp, log, sign, abs
from porepy.ad.utils import concatenate
